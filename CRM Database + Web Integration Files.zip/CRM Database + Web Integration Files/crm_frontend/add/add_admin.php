<?php
include '../db_connect.php';
if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $email = $_POST['email'];

    $check = $conn->query("SELECT * FROM Admin WHERE Email='$email'");
    if($check->num_rows>0){ echo "Email exists"; }
    else{
        $conn->query("INSERT INTO Admin (Username, Password, Role, Email) VALUES ('$username','$password','$role','$email')");
        header("Location: ../tables/admin.php"); exit;
    }
}
?>
<form method="POST">
Username: <input type="text" name="username" required><br>
Password: <input type="password" name="password" required><br>
Role: <input type="text" name="role" value="Admin"><br>
Email: <input type="email" name="email" required><br>
<input type="submit" name="submit" value="Add Admin">
</form>
