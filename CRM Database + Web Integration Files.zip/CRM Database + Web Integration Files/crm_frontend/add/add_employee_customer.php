<?php
include '../db_connect.php';
$employees=$conn->query("SELECT * FROM Employee");
$customers=$conn->query("SELECT * FROM Customer");
if(isset($_POST['submit'])){
    $emp=$_POST['employee']; $cus=$_POST['customer'];
    $conn->query("INSERT INTO EmployeeCustomer (EmployeeID,CustomerID) VALUES ($emp,$cus)");
    header("Location: ../tables/employee_customer.php"); exit;
}
?>
<form method="POST">
Employee: <select name="employee"><?php while($e=$employees->fetch_assoc()){
    echo "<option value='{$e['EmployeeID']}'>{$e['Firstname']} {$e['Lastname']}</option>"; }?></select><br>
Customer: <select name="customer"><?php while($c=$customers->fetch_assoc()){
    echo "<option value='{$c['CustomerID']}'>{$c['Firstname']} {$c['Lastname']}</option>"; }?></select><br>
<input type="submit" name="submit" value="Add Relation">
</form>
