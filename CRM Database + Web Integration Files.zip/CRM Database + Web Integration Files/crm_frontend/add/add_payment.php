<?php
include '../db_connect.php';
$orders=$conn->query("SELECT * FROM Orders");
if(isset($_POST['submit'])){
    $order=$_POST['order']; $amount=$_POST['amount']; $method=$_POST['method'];
    $conn->query("INSERT INTO Payment (OrderID,Amount,PaymentMethod) VALUES ($order,$amount,'$method')");
    header("Location: ../tables/payment.php"); exit;
}
?>
<form method="POST">
Order: <select name="order"><?php while($o=$orders->fetch_assoc()){
    echo "<option value='{$o['OrderID']}'>{$o['OrderID']}</option>"; }?></select><br>
Amount: <input type="number" step="0.01" name="amount" required><br>
Method: <input type="text" name="method" required><br>
<input type="submit" name="submit" value="Add Payment">
</form>
