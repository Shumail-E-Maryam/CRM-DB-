<?php
include '../db_connect.php';
if(isset($_POST['submit'])){
    $name=$_POST['name']; $desc=$_POST['desc']; $type=$_POST['type'];
    $price=$_POST['price']; $qty=$_POST['quantity'];
    $conn->query("INSERT INTO Item (Itemname,Description,Type,Price,QuantityAvailable)
    VALUES ('$name','$desc','$type',$price,$qty)");
    header("Location: ../tables/item.php"); exit;
}
?>
<form method="POST">
Name: <input type="text" name="name" required><br>
Description: <input type="text" name="desc"><br>
Type: <input type="text" name="type"><br>
Price: <input type="number" step="0.01" name="price" required><br>
Quantity: <input type="number" name="quantity" required><br>
<input type="submit" name="submit" value="Add Item">
</form>
