<?php
include '../db_connect.php';
$customers=$conn->query("SELECT * FROM Customer");
$employees=$conn->query("SELECT * FROM Employee");

if(isset($_POST['submit'])){
    $status=$_POST['status'];
    $address=$_POST['address'];
    $total=$_POST['total'];
    $customer=$_POST['customer'];
    $employee=$_POST['employee'];
    $conn->query("INSERT INTO Orders (Status,ShippingAddress,TotalAmount,CustomerID,EmployeeID)
    VALUES ('$status','$address',$total,$customer,$employee)");
    header("Location: ../tables/orders.php"); exit;
}
?>
<form method="POST">
Status: <input type="text" name="status" required><br>
Shipping Address: <input type="text" name="address" required><br>
Total Amount: <input type="number" step="0.01" name="total" required><br>
Customer: <select name="customer"><?php while($c=$customers->fetch_assoc()){
    echo "<option value='{$c['CustomerID']}'>{$c['Firstname']} {$c['Lastname']}</option>"; }?></select><br>
Employee: <select name="employee"><?php while($e=$employees->fetch_assoc()){
    echo "<option value='{$e['EmployeeID']}'>{$e['Firstname']} {$e['Lastname']}</option>"; }?></select><br>
<input type="submit" name="submit" value="Add Order">
</form>
