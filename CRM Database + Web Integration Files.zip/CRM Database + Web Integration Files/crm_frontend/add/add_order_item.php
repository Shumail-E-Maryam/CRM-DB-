<?php
include '../db_connect.php';
$orders=$conn->query("SELECT * FROM Orders");
$items=$conn->query("SELECT * FROM Item");
if(isset($_POST['submit'])){
    $order=$_POST['order']; $item=$_POST['item']; $qty=$_POST['quantity'];
    $price=$conn->query("SELECT Price FROM Item WHERE ItemID=$item")->fetch_assoc()['Price'];
    $subtotal=$qty*$price;
    $conn->query("INSERT INTO OrderItem (OrderID,ItemID,Quantity,Subtotal) VALUES ($order,$item,$qty,$subtotal)");
    header("Location: ../tables/order_item.php"); exit;
}
?>
<form method="POST">
Order: <select name="order"><?php while($o=$orders->fetch_assoc()){
    echo "<option value='{$o['OrderID']}'>{$o['OrderID']}</option>"; }?></select><br>
Item: <select name="item"><?php while($i=$items->fetch_assoc()){
    echo "<option value='{$i['ItemID']}'>{$i['Itemname']}</option>"; }?></select><br>
Quantity: <input type="number" name="quantity" value="1" required><br>
<input type="submit" name="submit" value="Add Relation">
</form>
