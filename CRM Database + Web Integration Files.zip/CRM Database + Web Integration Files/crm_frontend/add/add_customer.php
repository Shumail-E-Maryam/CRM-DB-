<?php
include '../db_connect.php';
if(isset($_POST['submit'])){
    $fname=$_POST['firstname']; $lname=$_POST['lastname']; $email=$_POST['email'];
    $phone=$_POST['phone']; $street=$_POST['street']; $city=$_POST['city'];
    $state=$_POST['state']; $zip=$_POST['zip']; $country=$_POST['country'];

    $check=$conn->query("SELECT * FROM Customer WHERE Email='$email'");
    if($check->num_rows>0){ echo "Email exists"; }
    else{
        $conn->query("INSERT INTO Customer (Firstname,Lastname,Email,Phone_no,Street,City,State,Zip,Country)
        VALUES ('$fname','$lname','$email','$phone','$street','$city','$state','$zip','$country')");
        header("Location: ../tables/customer.php"); exit;
    }
}
?>
<form method="POST">
Firstname: <input type="text" name="firstname" required><br>
Lastname: <input type="text" name="lastname" required><br>
Email: <input type="email" name="email" required><br>
Phone: <input type="text" name="phone" required><br>
Street: <input type="text" name="street"><br>
City: <input type="text" name="city"><br>
State: <input type="text" name="state"><br>
Zip: <input type="text" name="zip"><br>
Country: <input type="text" name="country" value="Pakistan"><br>
<input type="submit" name="submit" value="Add Customer">
</form>
