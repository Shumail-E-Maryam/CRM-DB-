<?php
include '../db_connect.php';
$admins=$conn->query("SELECT * FROM Admin");
if(isset($_POST['submit'])){
    $fname=$_POST['firstname']; $lname=$_POST['lastname'];
    $email=$_POST['email']; $phone=$_POST['phone'];
    $dept=$_POST['department']; $pos=$_POST['position']; $admin=$_POST['admin'];
    $conn->query("INSERT INTO Employee (Firstname,Lastname,Email,PhoneNumber,Department,Position,AdminID)
    VALUES ('$fname','$lname','$email','$phone','$dept','$pos',$admin)");
    header("Location: ../tables/employee.php"); exit;
}
?>
<form method="POST">
Firstname: <input type="text" name="firstname" required><br>
Lastname: <input type="text" name="lastname" required><br>
Email: <input type="email" name="email" required><br>
Phone: <input type="text" name="phone" required><br>
Department: <input type="text" name="department" required><br>
Position: <input type="text" name="position" required><br>
Admin: <select name="admin"><?php while($a=$admins->fetch_assoc()){
    echo "<option value='{$a['AdminID']}'>{$a['Username']}</option>"; }?></select><br>
<input type="submit" name="submit" value="Add Employee">
</form>
