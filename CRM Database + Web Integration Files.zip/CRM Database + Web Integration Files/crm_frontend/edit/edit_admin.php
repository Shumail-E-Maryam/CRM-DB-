<?php
include '../db_connect.php';
$id=$_GET['id'];
$row = $conn->query("SELECT * FROM Admin WHERE AdminID=$id")->fetch_assoc();

if(isset($_POST['submit'])){
    $username = $_POST['username'];
    $role = $_POST['role'];
    $email = $_POST['email'];
    $sql="UPDATE Admin SET Username='$username', Role='$role', Email='$email' WHERE AdminID=$id";
    $conn->query($sql);
    header("Location: ../tables/admin.php"); exit;
}
?>
<form method="POST">
Username: <input type="text" name="username" value="<?php echo $row['Username']; ?>" required><br>
Role: <input type="text" name="role" value="<?php echo $row['Role']; ?>"><br>
Email: <input type="email" name="email" value="<?php echo $row['Email']; ?>"><br>
<input type="submit" name="submit" value="Update Admin">
</form>
