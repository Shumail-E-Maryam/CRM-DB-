<?php
include '../db_connect.php';
$id=$_GET['id'];
$row=$conn->query("SELECT * FROM Item WHERE ItemID=$id")->fetch_assoc();
if(isset($_POST['submit'])){
    $name=$_POST['name']; $desc=$_POST['desc']; $type=$_POST['type'];
    $price=$_POST['price']; $qty=$_POST['quantity'];
    $conn->query("UPDATE Item SET Itemname='$name',Description='$desc',Type='$type',
    Price=$price,QuantityAvailable=$qty WHERE ItemID=$id");
    header("Location: ../tables/item.php"); exit;
}
?>
<form method="POST">
Name: <input type="text" name="name" value="<?php echo $row['Itemname']; ?>" required><br>
Description: <input type="text" name="desc" value="<?php echo $row['Description']; ?>"><br>
Type: <input type="text" name="type" value="<?php echo $row['Type']; ?>"><br>
Price: <input type="number" step="0.01" name="price" value="<?php echo $row['Price']; ?>" required><br>
Quantity: <input type="number" name="quantity" value="<?php echo $row['QuantityAvailable']; ?>" required><br>
<input type="submit" name="submit" value="Update Item">
</form>
