<?php
include '../db_connect.php';
$id=$_GET['id'];
$row=$conn->query("SELECT * FROM Orders WHERE OrderID=$id")->fetch_assoc();
$customers=$conn->query("SELECT * FROM Customer");
$employees=$conn->query("SELECT * FROM Employee");

if(isset($_POST['submit'])){
    $status=$_POST['status'];
    $address=$_POST['address'];
    $total=$_POST['total'];
    $customer=$_POST['customer'];
    $employee=$_POST['employee'];
    $conn->query("UPDATE Orders SET Status='$status',ShippingAddress='$address',
    TotalAmount=$total,CustomerID=$customer,EmployeeID=$employee WHERE OrderID=$id");
    header("Location: ../tables/orders.php"); exit;
}
?>
<form method="POST">
Status: <input type="text" name="status" value="<?php echo $row['Status']; ?>" required><br>
Shipping Address: <input type="text" name="address" value="<?php echo $row['ShippingAddress']; ?>" required><br>
Total Amount: <input type="number" step="0.01" name="total" value="<?php echo $row['TotalAmount']; ?>" required><br>
Customer: <select name="customer"><?php while($c=$customers->fetch_assoc()){
$sel=$c['CustomerID']==$row['CustomerID']?"selected":""; echo "<option value='{$c['CustomerID']}' $sel>{$c['Firstname']} {$c['Lastname']}</option>"; }?></select><br>
Employee: <select name="employee"><?php while($e=$employees->fetch_assoc()){
$sel=$e['EmployeeID']==$row['EmployeeID']?"selected":""; echo "<option value='{$e['EmployeeID']}' $sel>{$e['Firstname']} {$e['Lastname']}</option>"; }?></select><br>
<input type="submit" name="submit" value="Update Order">
</form>
