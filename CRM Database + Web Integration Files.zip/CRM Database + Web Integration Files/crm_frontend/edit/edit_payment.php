<?php
include '../db_connect.php';
$id=$_GET['id'];
$row=$conn->query("SELECT * FROM Payment WHERE PaymentID=$id")->fetch_assoc();
$orders=$conn->query("SELECT * FROM Orders");
if(isset($_POST['submit'])){
    $order=$_POST['order']; $amount=$_POST['amount']; $method=$_POST['method'];
    $conn->query("UPDATE Payment SET OrderID=$order,Amount=$amount,PaymentMethod='$method' WHERE PaymentID=$id");
    header("Location: ../tables/payment.php"); exit;
}
?>
<form method="POST">
Order: <select name="order"><?php while($o=$orders->fetch_assoc()){
$sel=$o['OrderID']==$row['OrderID']?"selected":""; echo "<option value='{$o['OrderID']}' $sel>{$o['OrderID']}</option>"; }?></select><br>
Amount: <input type="number" step="0.01" name="amount" value="<?php echo $row['Amount']; ?>" required><br>
Method: <input type="text" name="method" value="<?php echo $row['PaymentMethod']; ?>" required><br>
<input type="submit" name="submit" value="Update Payment">
</form>
