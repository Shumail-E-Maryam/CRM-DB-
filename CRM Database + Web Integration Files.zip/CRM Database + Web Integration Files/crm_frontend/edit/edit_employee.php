<?php
include '../db_connect.php';
$id=$_GET['id'];
$row=$conn->query("SELECT * FROM Employee WHERE EmployeeID=$id")->fetch_assoc();
$admins=$conn->query("SELECT * FROM Admin");

if(isset($_POST['submit'])){
    $fname=$_POST['firstname']; $lname=$_POST['lastname'];
    $email=$_POST['email']; $phone=$_POST['phone'];
    $dept=$_POST['department']; $pos=$_POST['position']; $admin=$_POST['admin'];
    $conn->query("UPDATE Employee SET Firstname='$fname',Lastname='$lname',Email='$email',PhoneNumber='$phone',
    Department='$dept',Position='$pos',AdminID=$admin WHERE EmployeeID=$id");
    header("Location: ../tables/employee.php"); exit;
}
?>
<form method="POST">
Firstname: <input type="text" name="firstname" value="<?php echo $row['Firstname']; ?>" required><br>
Lastname: <input type="text" name="lastname" value="<?php echo $row['Lastname']; ?>" required><br>
Email: <input type="email" name="email" value="<?php echo $row['Email']; ?>" required><br>
Phone: <input type="text" name="phone" value="<?php echo $row['PhoneNumber']; ?>" required><br>
Department: <input type="text" name="department" value="<?php echo $row['Department']; ?>" required><br>
Position: <input type="text" name="position" value="<?php echo $row['Position']; ?>" required><br>
Admin: <select name="admin"><?php while($a=$admins->fetch_assoc()){
$sel=$a['AdminID']==$row['AdminID']?"selected":""; echo "<option value='{$a['AdminID']}' $sel>{$a['Username']}</option>"; }?></select><br>
<input type="submit" name="submit" value="Update Employee">
</form>
