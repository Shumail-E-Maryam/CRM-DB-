<?php
include '../db_connect.php';
$id=$_GET['id'];
$row=$conn->query("SELECT * FROM Customer WHERE CustomerID=$id")->fetch_assoc();
if(isset($_POST['submit'])){
    $fname=$_POST['firstname']; $lname=$_POST['lastname']; $email=$_POST['email'];
    $phone=$_POST['phone']; $street=$_POST['street']; $city=$_POST['city'];
    $state=$_POST['state']; $zip=$_POST['zip']; $country=$_POST['country'];
    $conn->query("UPDATE Customer SET Firstname='$fname',Lastname='$lname',Email='$email',
    Phone_no='$phone',Street='$street',City='$city',State='$state',Zip='$zip',Country='$country'
    WHERE CustomerID=$id");
    header("Location: ../tables/customer.php"); exit;
}
?>
<form method="POST">
Firstname: <input type="text" name="firstname" value="<?php echo $row['Firstname']; ?>" required><br>
Lastname: <input type="text" name="lastname" value="<?php echo $row['Lastname']; ?>" required><br>
Email: <input type="email" name="email" value="<?php echo $row['Email']; ?>" required><br>
Phone: <input type="text" name="phone" value="<?php echo $row['Phone_no']; ?>" required><br>
Street: <input type="text" name="street" value="<?php echo $row['Street']; ?>"><br>
City: <input type="text" name="city" value="<?php echo $row['City']; ?>"><br>
State: <input type="text" name="state" value="<?php echo $row['State']; ?>"><br>
Zip: <input type="text" name="zip" value="<?php echo $row['Zip']; ?>"><br>
Country: <input type="text" name="country" value="<?php echo $row['Country']; ?>"><br>
<input type="submit" name="submit" value="Update Customer">
</form>
