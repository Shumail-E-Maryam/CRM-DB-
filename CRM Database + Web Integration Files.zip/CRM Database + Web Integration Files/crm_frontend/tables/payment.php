<?php include '../db_connect.php'; ?>
<h1>Payments</h1>
<a href="../add/add_payment.php">Add Payment</a>
<table border="1">
<tr><th>ID</th><th>Order</th><th>Amount</th><th>Date</th><th>Method</th><th>Actions</th></tr>
<?php
$result=$conn->query("SELECT p.*, o.OrderID FROM Payment p JOIN Orders o ON p.OrderID=o.OrderID");
while($row=$result->fetch_assoc()){
    echo "<tr>
    <td>{$row['PaymentID']}</td>
    <td>{$row['OrderID']}</td>
    <td>{$row['Amount']}</td>
    <td>{$row['Payment_Date']}</td>
    <td>{$row['PaymentMethod']}</td>
    <td>
        <a href='../edit/edit_payment.php?id={$row['PaymentID']}'>Edit</a> |
        <a href='../delete/delete_payment.php?id={$row['PaymentID']}'>Delete</a>
    </td>
    </tr>";
}
?>
</table>
