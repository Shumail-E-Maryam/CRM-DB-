<?php
include '../db_connect.php';
?>
<h1>Employee-Customer Relations</h1>
<a href="../add/add_employee_customer.php">Add Relation</a>
<table border="1">
<tr><th>Employee</th><th>Customer</th><th>Actions</th></tr>
<?php
$result=$conn->query("SELECT ec.EmployeeID,ec.CustomerID,e.Firstname AS EmpF,e.Lastname AS EmpL,
c.Firstname AS CusF,c.Lastname AS CusL
FROM EmployeeCustomer ec
JOIN Employee e ON ec.EmployeeID=e.EmployeeID
JOIN Customer c ON ec.CustomerID=c.CustomerID");
while($row=$result->fetch_assoc()){
    echo "<tr>
    <td>{$row['EmpF']} {$row['EmpL']}</td>
    <td>{$row['CusF']} {$row['CusL']}</td>
    <td>
        <a href='../delete/delete_employee_customer.php?emp={$row['EmployeeID']}&cus={$row['CustomerID']}'>Delete</a>
    </td>
    </tr>";
}
?>
</table>
