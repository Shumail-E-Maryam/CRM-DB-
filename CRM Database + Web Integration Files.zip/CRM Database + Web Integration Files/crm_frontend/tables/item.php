<?php include '../db_connect.php'; ?>
<h1>Items</h1>
<a href="../add/add_item.php">Add Item</a>
<table border="1">
<tr><th>ID</th><th>Name</th><th>Description</th><th>Type</th><th>Price</th><th>Quantity</th><th>Actions</th></tr>
<?php
$result=$conn->query("SELECT * FROM Item");
while($row=$result->fetch_assoc()){
    echo "<tr>
    <td>{$row['ItemID']}</td>
    <td>{$row['Itemname']}</td>
    <td>{$row['Description']}</td>
    <td>{$row['Type']}</td>
    <td>{$row['Price']}</td>
    <td>{$row['QuantityAvailable']}</td>
    <td>
        <a href='../edit/edit_item.php?id={$row['ItemID']}'>Edit</a> |
        <a href='../delete/delete_item.php?id={$row['ItemID']}'>Delete</a>
    </td>
    </tr>";
}
?>
</table>
