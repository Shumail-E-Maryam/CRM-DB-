<?php include '../db_connect.php'; ?>
<h1>Customers</h1>
<a href="../add/add_customer.php">Add Customer</a>
<table border="1">
<tr>
<th>ID</th><th>Firstname</th><th>Lastname</th><th>Email</th><th>Phone</th><th>Street</th>
<th>City</th><th>State</th><th>Zip</th><th>Country</th><th>Actions</th>
</tr>
<?php
$result=$conn->query("SELECT * FROM Customer");
while($row=$result->fetch_assoc()){
    echo "<tr>
    <td>{$row['CustomerID']}</td>
    <td>{$row['Firstname']}</td>
    <td>{$row['Lastname']}</td>
    <td>{$row['Email']}</td>
    <td>{$row['Phone_no']}</td>
    <td>{$row['Street']}</td>
    <td>{$row['City']}</td>
    <td>{$row['State']}</td>
    <td>{$row['Zip']}</td>
    <td>{$row['Country']}</td>
    <td>
        <a href='../edit/edit_customer.php?id={$row['CustomerID']}'>Edit</a> |
        <a href='../delete/delete_customer.php?id={$row['CustomerID']}'>Delete</a>
    </td>
    </tr>";
}
?>
</table>
