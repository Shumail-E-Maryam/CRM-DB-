<?php include '../db_connect.php'; ?>
<h1>Orders</h1>
<a href="../add/add_order.php">Add Order</a>
<table border="1">
<tr>
<th>ID</th><th>Order Date</th><th>Status</th><th>Shipping Address</th>
<th>Total Amount</th><th>Customer</th><th>Employee</th><th>Actions</th>
</tr>
<?php
$result=$conn->query("SELECT o.*, c.Firstname AS CusFirst, c.Lastname AS CusLast,
                      e.Firstname AS EmpFirst, e.Lastname AS EmpLast
                      FROM Orders o
                      JOIN Customer c ON o.CustomerID=c.CustomerID
                      JOIN Employee e ON o.EmployeeID=e.EmployeeID");
while($row=$result->fetch_assoc()){
    echo "<tr>
    <td>{$row['OrderID']}</td>
    <td>{$row['OrderDate']}</td>
    <td>{$row['Status']}</td>
    <td>{$row['ShippingAddress']}</td>
    <td>{$row['TotalAmount']}</td>
    <td>{$row['CusFirst']} {$row['CusLast']}</td>
    <td>{$row['EmpFirst']} {$row['EmpLast']}</td>
    <td>
        <a href='../edit/edit_order.php?id={$row['OrderID']}'>Edit</a> |
        <a href='../delete/delete_order.php?id={$row['OrderID']}'>Delete</a>
    </td>
    </tr>";
}
?>
</table>
