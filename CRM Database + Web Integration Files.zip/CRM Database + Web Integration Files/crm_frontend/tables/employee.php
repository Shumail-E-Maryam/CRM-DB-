<?php include '../db_connect.php'; ?>
<h1>Employees</h1>
<a href="../add/add_employee.php">Add Employee</a>
<table border="1">
<tr>
<th>ID</th><th>Firstname</th><th>Lastname</th><th>Email</th><th>Phone</th><th>Dept</th><th>Position</th><th>AdminID</th><th>Actions</th>
</tr>
<?php
$result=$conn->query("SELECT * FROM Employee");
while($row=$result->fetch_assoc()){
    echo "<tr>
    <td>{$row['EmployeeID']}</td>
    <td>{$row['Firstname']}</td>
    <td>{$row['Lastname']}</td>
    <td>{$row['Email']}</td>
    <td>{$row['PhoneNumber']}</td>
    <td>{$row['Department']}</td>
    <td>{$row['Position']}</td>
    <td>{$row['AdminID']}</td>
    <td>
        <a href='../edit/edit_employee.php?id={$row['EmployeeID']}'>Edit</a> |
        <a href='../delete/delete_employee.php?id={$row['EmployeeID']}'>Delete</a>
    </td>
    </tr>";
}
?>
</table>
