<?php
include '../db_connect.php';
?>
<h1>Order-Item Relations</h1>
<a href="../add/add_order_item.php">Add Relation</a>
<table border="1">
<tr><th>Order</th><th>Item</th><th>Quantity</th><th>Subtotal</th><th>Actions</th></tr>
<?php
$result=$conn->query("SELECT oi.OrderID,oi.ItemID,oi.Quantity,oi.Subtotal,
o.OrderID AS OID,i.Itemname FROM OrderItem oi
JOIN Orders o ON oi.OrderID=o.OrderID
JOIN Item i ON oi.ItemID=i.ItemID");
while($row=$result->fetch_assoc()){
    echo "<tr>
    <td>{$row['OID']}</td>
    <td>{$row['Itemname']}</td>
    <td>{$row['Quantity']}</td>
    <td>{$row['Subtotal']}</td>
    <td>
        <a href='../delete/delete_order_item.php?order={$row['OrderID']}&item={$row['ItemID']}'>Delete</a>
    </td>
    </tr>";
}
?>
</table>
