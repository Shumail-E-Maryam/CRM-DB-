<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit;
}
require "db_connect.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>CRM System</title>
    <link rel="stylesheet" href="style.css">

    <!-- AI CHAT BOX STYLE -->
    <style>
        #ai-box {
            margin-top: 20px;
            padding: 20px;
            background: #f4f4f4;
            border-radius: 8px;
        }
        #ai-response {
            margin-top: 10px;
            padding: 15px;
            background: white;
            border-left: 4px solid #3498db;
        }
        textarea {
            width: 100%;
            height: 80px;
            padding: 10px;
        }
        button {
            padding: 10px 18px;
            background: #3498db;
            color: white;
            border: none;
            cursor: pointer;
            margin-top: 10px;
        }
    </style>
</head>

<body>
<div class="container">

    <h1>CRM Management System</h1>

    <!-- MENU -->
    <div class="menu">
        <a href="index.php?show=customers">Customers</a>
        <a href="index.php?show=employees">Employees</a>
        <a href="index.php?show=items">Items</a>
        <a href="index.php?show=orders">Orders</a>
        <a href="index.php?show=payments">Payments</a>
        <a href="index.php?show=emp_cust">Employee-Customer</a>
        <a href="index.php?show=order_item">Order-Item</a>
        <a href="index.php?add=customer">+ Add Customer</a>
        <a href="logout.php" style="margin-left:auto; background:#e74c3c;">Logout</a>
    </div>

    <!-- SHOW TABLE DATA -->
    <?php
    if (isset($_GET['show'])) {
        $table = $_GET['show'];

        $valid = [
            "customers" => "customer",
            "employees" => "employee",
            "items" => "item",
            "orders" => "orders",
            "payments" => "payment",
            "emp_cust" => "employeecustomer",
            "order_item" => "orderitem"
        ];

        if (!isset($valid[$table])) {
            echo "<h2>Invalid Table</h2>";
            exit;
        }

        $table_name = $valid[$table];
        echo "<h2>Showing: $table_name</h2>";

        $result = $conn->query("SELECT * FROM $table_name");

        if ($result->num_rows > 0) {
           echo '<div class="table-container">';
           echo "<table><tr>";

            while ($col = $result->fetch_field()) {
                echo "<th>".$col->name."</th>";
            }

            echo "</tr>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                foreach ($row as $data) {
                    echo "<td>".$data."</td>";
                }
                echo "</tr>";
            }

            echo "</table>";
            echo "</div>";
        } else {
            echo "<p>No data found.</p>";
        }
    }
    ?>

    <!-- ADD CUSTOMER FORM -->
    <?php if (isset($_GET['add']) && $_GET['add'] == "customer"): ?>
        <h2>Add a Customer</h2>

        <form method="POST" action="save_customer.php">

            <label>First Name:</label>
            <input type="text" name="Firstname" required>

            <label>Last Name:</label>
            <input type="text" name="Lastname" required>

            <label>Email:</label>
            <input type="email" name="Email" required>

            <label>Phone Number:</label>
            <input type="text" name="Phone_no" required>

            <label>Street:</label>
            <input type="text" name="Street">

            <label>City:</label>
            <input type="text" name="City">

            <label>State:</label>
            <input type="text" name="State">

            <label>Zip:</label>
            <input type="text" name="Zip">

            <label>Country:</label>
            <input type="text" name="Country" value="Pakistan">

            <button type="submit">Save Customer</button>
        </form>
    <?php endif; ?>


    <!-- AI INTEGRATION BOX -->
    <div id="ai-box">
        <h2>AI CRM Assistant 🤖</h2>
        <p>Ask anything about your CRM data. Example:  
           <i>“Summarize total customers, top orders, frequent buyers”</i></p>

        <form method="POST">
            <textarea name="query" placeholder="Ask something..."></textarea>
            <button type="submit" name="ask_ai">Ask AI</button>
        </form>

        <?php
        if (isset($_POST['ask_ai'])) {
            $user_question = $_POST['query'];

            $data = [
                "model" => "gpt-4.1",
                "messages" => [
                    ["role" => "system", "content" => "You are an AI CRM Assistant. Analyze and explain CRM insights."],
                    ["role" => "user", "content" => $user_question]
                ]
            ];

            $ch = curl_init("https://api.openai.com/v1/chat/completions");
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Content-Type: application/json",
                "Authorization: Bearer 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"
            ]);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);
            $response = json_decode($response, true);

            if (isset($response["choices"][0]["message"]["content"])) {
                echo "<div id='ai-response'><strong>AI Response:</strong><br>" . nl2br($response["choices"][0]["message"]["content"]) . "</div>";
            }
        }
        ?>
    </div>


</div>
</body>
</html>
