<?php
require "db_connect.php";

$firstname = $_POST['Firstname'];
$lastname = $_POST['Lastname'];
$email = $_POST['Email'];
$phone = $_POST['Phone_no'];
$street = $_POST['Street'];
$city = $_POST['City'];
$state = $_POST['State'];
$zip = $_POST['Zip'];
$country = $_POST['Country'];

$sql = "INSERT INTO customer 
(Firstname, Lastname, Email, Phone_no, Street, City, State, Zip, Country)
VALUES 
('$firstname', '$lastname', '$email', '$phone', '$street', '$city', '$state', '$zip', '$country')";

if ($conn->query($sql)) {
    header("Location: index.php?show=customers");
    exit;
} else {
    echo "Error: " . $conn->error;
}
?>
