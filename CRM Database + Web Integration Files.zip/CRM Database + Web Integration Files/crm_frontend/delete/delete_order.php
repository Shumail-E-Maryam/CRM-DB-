<?php
include '../db_connect.php';
$id=$_GET['id'];
$conn->query("DELETE FROM Orders WHERE OrderID=$id");
header("Location: ../tables/orders.php"); exit;
?>
