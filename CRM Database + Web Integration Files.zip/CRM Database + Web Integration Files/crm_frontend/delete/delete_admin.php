<?php
include '../db_connect.php';
$id=$_GET['id'];
$conn->query("DELETE FROM Admin WHERE AdminID=$id");
header("Location: ../tables/admin.php");
exit;
?>
