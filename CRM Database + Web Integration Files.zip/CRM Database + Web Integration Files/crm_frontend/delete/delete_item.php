<?php
include '../db_connect.php';
$id=$_GET['id'];
$conn->query("DELETE FROM Item WHERE ItemID=$id");
header("Location: ../tables/item.php"); exit;
?>
