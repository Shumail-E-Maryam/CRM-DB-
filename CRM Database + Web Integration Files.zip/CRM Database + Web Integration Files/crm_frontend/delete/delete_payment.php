<?php
include '../db_connect.php';
$id=$_GET['id'];
$conn->query("DELETE FROM Payment WHERE PaymentID=$id");
header("Location: ../tables/payment.php"); exit;
?>
