<?php
include '../db_connect.php';
$id=$_GET['id'];
$conn->query("DELETE FROM Customer WHERE CustomerID=$id");
header("Location: ../tables/customer.php"); exit;
?>
