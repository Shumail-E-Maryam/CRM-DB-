<?php
include '../db_connect.php';
$order=$_GET['order']; $item=$_GET['item'];
$conn->query("DELETE FROM OrderItem WHERE OrderID=$order AND ItemID=$item");
header("Location: ../tables/order_item.php"); exit;
?>
