<?php
include '../db_connect.php';
$emp=$_GET['emp']; $cus=$_GET['cus'];
$conn->query("DELETE FROM EmployeeCustomer WHERE EmployeeID=$emp AND CustomerID=$cus");
header("Location: ../tables/employee_customer.php"); exit;
?>
