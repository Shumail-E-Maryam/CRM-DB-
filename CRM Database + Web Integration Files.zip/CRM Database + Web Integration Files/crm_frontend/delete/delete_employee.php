<?php include '../db_connect.php'; $id=$_GET['id'];
$conn->query("DELETE FROM Employee WHERE EmployeeID=$id");
header("Location: ../tables/employee.php"); exit;
?>
