<?php
session_start();
require "db_connect.php";

$username = $_POST['username'];
$password = $_POST['password'];

// Check Admin table for username or email
$sql = "SELECT * FROM Admin WHERE Username=? OR Email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $username, $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
    
    // Plain-text password check
    if ($password == $row['Password']) {
        // Successful login
        $_SESSION['username'] = $row['Username'];
        $_SESSION['role'] = $row['Role'];
        $_SESSION['adminID'] = $row['AdminID'];
        header("Location: index.php");
        exit;
    } else {
        echo "Invalid password. <a href='login.php'>Go back</a>";
    }
} else {
    echo "Invalid username/email. <a href='login.php'>Go back</a>";
}
?>
