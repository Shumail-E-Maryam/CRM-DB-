-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: crm_management_systems
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `CustomerID` int NOT NULL AUTO_INCREMENT,
  `Firstname` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Lastname` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Phone_no` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `Street` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `City` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `State` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Zip` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Country` varchar(50) COLLATE utf8mb4_general_ci DEFAULT 'Pakistan',
  PRIMARY KEY (`CustomerID`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Ahsan','Ahmed','ahsan.ahmed@yahoo.com','+923543104799','53 Street I','Lahore','Punjab','51702','Pakistan'),(2,'Sana','Ali','sana.ali@gmail.com','+923985989496','18 Street B','Karachi','Sindh','55386','Pakistan'),(3,'Sara','Malik','sara.malik@yahoo.com','+923697371433','8 Street B','Islamabad','Capital','73524','Pakistan'),(4,'Zain','Ahmed','zain.ahmed@hotmail.com','+923136754855','82 Street M','Multan','Punjab','79512','Pakistan'),(5,'Raza','Rauf','raza.rauf@crm.com','+923857691309','38 Street H','Karachi','Sindh','10140','Pakistan'),(6,'Rimsha','Malik','rimsha.malik@yahoo.com','+923155359369','41 Street O','Islamabad','Capital','45499','Pakistan'),(7,'Hamza','Malik','hamza.malik@crm.com','+923364866196','3 Street U','Peshawar','KPK','56184','Pakistan'),(8,'Taha','Rauf','taha.rauf@yahoo.com','+923297579732','51 Street E','Lahore','Punjab','85074','Pakistan'),(9,'Bilal','Khan','bilal.khan@crm.com','+923417750010','72 Street A','Peshawar','KPK','83121','Pakistan'),(10,'Maha','Ali','maha.ali@gmail.com','+923803545780','7 Street Y','Multan','Punjab','62519','Pakistan'),(11,'Nimra','Ahmed','nimra.ahmed@gmail.com','+923999502666','68 Street P','Multan','Punjab','40394','Pakistan'),(12,'Nimra','Aslam','nimra.aslam@gmail.com','+923308957421','22 Street P','Islamabad','Capital','62870','Pakistan'),(13,'Sara','Iqbal','sara.iqbal@crm.com','+923578476018','40 Street N','Islamabad','Capital','31842','Pakistan'),(14,'Zain','Rehman','zain.rehman@crm.com','+923586492153','28 Street V','Lahore','Punjab','46535','Pakistan'),(15,'Sara','Ali','sara.ali@crm.com','+923342866822','98 Street D','Peshawar','KPK','80781','Pakistan'),(16,'Nimra','Rauf','nimra.rauf@yahoo.com','+923713745342','84 Street N','Peshawar','KPK','35607','Pakistan'),(17,'Ahsan','Aslam','ahsan.aslam@crm.com','+923355013208','10 Street V','Karachi','Sindh','10838','Pakistan'),(18,'Hamza','Malik','hamza.malik@gmail.com','+923492446815','32 Street V','Faisalabad','Punjab','91823','Pakistan'),(19,'Hamza','Rehman','hamza.rehman@gmail.com','+923569814646','47 Street A','Faisalabad','Punjab','99039','Pakistan'),(20,'Zain','Rehman','zain.rehman@hotmail.com','+923539540093','79 Street I','Faisalabad','Punjab','88508','Pakistan'),(21,'Rimsha','Rehman','rimsha.rehman@hotmail.com','+923281800104','65 Street K','Lahore','Punjab','64310','Pakistan'),(22,'Areeba','Shah','areeba.shah@yahoo.com','+923441627676','84 Street O','Lahore','Punjab','67738','Pakistan'),(23,'Fahad','Khan','fahad.khan@yahoo.com','+923240503515','73 Street R','Karachi','Sindh','20575','Pakistan'),(24,'Hamza','Iqbal','hamza.iqbal@crm.com','+923170006180','54 Street R','Lahore','Punjab','48650','Pakistan'),(25,'Laiba','Malik','laiba.malik@gmail.com','+923104878677','22 Street J','Multan','Punjab','70667','Pakistan'),(26,'Ahsan','Rehman','ahsan.rehman@yahoo.com','+923319083280','52 Street A','Faisalabad','Punjab','11091','Pakistan'),(27,'Ahsan','Rehman','ahsan.rehman@crm.com','+923988747150','80 Street X','Karachi','Sindh','86596','Pakistan'),(28,'Raza','Mirza','raza.mirza@yahoo.com','+923642373785','58 Street K','Peshawar','KPK','88249','Pakistan'),(29,'Amna','Shah','amna.shah@yahoo.com','+923710678478','37 Street Y','Islamabad','Capital','87116','Pakistan'),(30,'Maha','Mirza','maha.mirza@hotmail.com','+923471281345','92 Street V','Multan','Punjab','29693','Pakistan'),(31,'Amna','Rehman','amna.rehman@hotmail.com','+923243831146','74 Street Q','Multan','Punjab','26794','Pakistan'),(32,'Ali','Khan','ali.khan@hotmail.com','+923761109884','10 Street O','Multan','Punjab','77015','Pakistan'),(33,'Usman','Shah','usman.shah@yahoo.com','+923666071608','67 Street D','Faisalabad','Punjab','50336','Pakistan'),(34,'Rimsha','Shah','rimsha.shah@yahoo.com','+923139292125','83 Street N','Karachi','Sindh','32932','Pakistan'),(35,'Bilal','Qureshi','bilal.qureshi@hotmail.com','+923345256386','38 Street E','Faisalabad','Punjab','10708','Pakistan'),(36,'Sana','Aslam','sana.aslam@gmail.com','+923388437514','7 Street H','Islamabad','Capital','56893','Pakistan'),(37,'Laiba','Shah','laiba.shah@yahoo.com','+923447977551','27 Street X','Multan','Punjab','51103','Pakistan'),(38,'Fahad','Qureshi','fahad.qureshi@crm.com','+923726645103','32 Street B','Karachi','Sindh','83965','Pakistan'),(39,'Areeba','Mirza','areeba.mirza@crm.com','+923319345208','13 Street F','Faisalabad','Punjab','12122','Pakistan'),(40,'Nimra','Ali','nimra.ali@yahoo.com','+923932719359','8 Street I','Karachi','Sindh','24728','Pakistan'),(41,'Taha','Ahmed','taha.ahmed@yahoo.com','+923724826934','22 Street V','Islamabad','Capital','11790','Pakistan'),(42,'Taha','Shah','taha.shah@yahoo.com','+923927305934','83 Street J','Multan','Punjab','40455','Pakistan'),(43,'Ali','Mirza','ali.mirza@gmail.com','+923907276135','27 Street F','Multan','Punjab','30614','Pakistan'),(44,'Raza','Rehman','raza.rehman@crm.com','+923326189800','4 Street X','Peshawar','KPK','66920','Pakistan'),(46,'Fatima','Iqbal','fatima.iqbal@hotmail.com','+923584973177','22 Street A','Karachi','Sindh','20357','Pakistan'),(47,'Rimsha','Rehman','rimsha.rehman@crm.com','+923495931294','39 Street Z','Karachi','Sindh','58347','Pakistan'),(48,'Raza','Iqbal','raza.iqbal@hotmail.com','+923862089221','34 Street M','Multan','Punjab','66254','Pakistan'),(49,'Ahsan','Malik','ahsan.malik@hotmail.com','+923373442585','82 Street T','Islamabad','Capital','81577','Pakistan'),(50,'Rimsha','Ahmed','rimsha.ahmed@hotmail.com','+923410513631','27 Street C','Multan','Punjab','99512','Pakistan');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-19 12:16:23
