-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: crm_management_systems
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item` (
  `ItemID` int NOT NULL AUTO_INCREMENT,
  `Itemname` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `Description` text COLLATE utf8mb4_general_ci,
  `Type` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Price` decimal(10,2) NOT NULL,
  `QuantityAvailable` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ItemID`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES (1,'Lavender Bliss Soap','Handmade lavender-scented soap for smooth skin','Soap',1416.07,24),(2,'Aloe Vera Shampoo','Organic shampoo with aloe vera extracts','Shampoo',1317.13,61),(3,'Rose Glow Lotion','Moisturizing lotion with rose essence','Lotion',777.06,63),(4,'Coconut Hair Oil','Natural coconut oil for strong and shiny hair','Hair Oil',1434.20,55),(5,'Vanilla Mist Perfume','Soft vanilla fragrance for daily wear','Perfume',1286.49,39),(6,'Lemon Fresh Soap','Refreshing lemon-scented cleansing bar','Soap',1129.28,61),(7,'Charcoal Detox Mask','Deep-cleansing charcoal face mask','Face Mask',1399.81,33),(8,'Green Tea Cleanser','Gentle green tea face cleanser','Cleanser',815.19,94),(9,'Honey Hydration Lotion','Hydrating lotion with natural honey','Lotion',494.60,27),(10,'Argan Hair Serum','Smoothening serum for frizz-free hair','Hair Serum',1150.97,13),(11,'Mint Cool Shampoo','Cooling mint formula for scalp freshness','Shampoo',365.71,93),(12,'Peach Blossom Perfume','Fruity floral fragrance for women','Perfume',312.76,51),(13,'Coffee Scrub','Exfoliating scrub with coffee and shea butter','Scrub',1105.67,83),(14,'Shea Butter Cream','Intense moisturizing cream for dry skin','Cream',1126.85,61),(15,'Rosemary Conditioner','Natural conditioner with rosemary oil','Conditioner',1069.97,84),(16,'Cucumber Face Wash','Refreshing face wash with cucumber extracts','Face Wash',1097.28,43),(17,'Aloe Vera Gel','Pure aloe vera soothing skin gel','Gel',1439.11,68),(18,'Jasmine Body Mist','Light jasmine body spray','Perfume',1097.95,64),(19,'Oatmeal Bath Soap','Gentle exfoliating oatmeal soap bar','Soap',596.57,20),(20,'Avocado Hair Mask','Nourishing hair mask for damaged hair','Hair Mask',385.99,89),(21,'Sandalwood Lotion','Herbal sandalwood moisturizing lotion','Lotion',682.58,83),(22,'Tea Tree Toner','Acne-control toner with tea tree oil','Toner',1361.41,80),(23,'Coconut Body Butter','Rich body butter for deep hydration','Body Butter',280.71,11),(24,'Rose Lip Balm','Moisturizing lip balm with rose tint','Lip Balm',372.49,62),(25,'Lemon Zest Shampoo','Vitamin-rich lemon shampoo','Shampoo',562.52,92),(26,'Lavender Bath Salt','Relaxing bath salt with lavender essence','Bath Salt',869.44,93),(27,'Aloe & Cucumber Cream','Cooling face cream with aloe and cucumber','Cream',349.41,21),(28,'Berry Bliss Scrub','Fruit-based exfoliating scrub','Scrub',748.07,29),(29,'Cocoa Butter Lotion','Softening lotion for glowing skin','Lotion',503.23,76),(30,'Herbal Hair Tonic','Natural tonic for hair growth','Hair Tonic',568.84,76),(31,'Orange Blossom Perfume','Fresh citrus floral fragrance','Perfume',1294.13,78),(32,'Neem Face Wash','Anti-acne herbal face wash','Face Wash',1055.08,43),(33,'Papaya Soap','Brightening soap with papaya extracts','Soap',490.41,80),(34,'Mango Body Lotion','Sweet mango-scented body lotion','Lotion',1001.20,20),(35,'Clay Purify Mask','Mineral-rich clay purifying mask','Face Mask',337.88,30),(36,'Rose Water Toner','Refreshing rose water toner','Toner',851.41,24),(37,'Aloe Mint Gel','Cooling aloe and mint after-sun gel','Gel',881.86,33),(38,'Chamomile Night Cream','Soothing night cream with chamomile','Cream',435.27,57),(39,'Pearl Glow Serum','Brightening serum with pearl essence','Serum',1356.24,76);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-19 12:16:22
