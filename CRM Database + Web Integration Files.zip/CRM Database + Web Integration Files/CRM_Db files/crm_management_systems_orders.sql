-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: crm_management_systems
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `OrderID` int NOT NULL AUTO_INCREMENT,
  `OrderDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Status` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `ShippingAddress` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `TotalAmount` decimal(10,2) NOT NULL,
  `CustomerID` int NOT NULL,
  `EmployeeID` int NOT NULL,
  PRIMARY KEY (`OrderID`),
  KEY `CustomerID` (`CustomerID`),
  KEY `EmployeeID` (`EmployeeID`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customer` (`CustomerID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`EmployeeID`) REFERENCES `employee` (`EmployeeID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'2025-02-10 00:00:00','Shipped','95 Faisalabad Street, Faisalabad',3204.64,48,18),(2,'2025-02-05 00:00:00','Processing','56 Peshawar Street, Peshawar',3766.90,24,6),(3,'2025-07-08 00:00:00','Processing','48 Karachi Street, Karachi',1975.29,42,16),(4,'2025-10-04 00:00:00','Processing','43 Multan Street, Multan',4284.62,32,14),(5,'2025-08-21 00:00:00','Pending','10 Peshawar Street, Peshawar',4801.01,21,7),(6,'2025-03-24 00:00:00','Cancelled','52 Islamabad Street, Islamabad',746.71,39,12),(7,'2025-10-12 00:00:00','Delivered','44 Karachi Street, Karachi',1294.50,35,10),(8,'2025-05-01 00:00:00','Delivered','84 Karachi Street, Karachi',525.57,9,14),(9,'2025-09-16 00:00:00','Pending','31 Lahore Street, Lahore',2589.67,4,9),(10,'2025-09-18 00:00:00','Shipped','57 Peshawar Street, Peshawar',3950.57,11,9),(11,'2025-03-30 00:00:00','Processing','83 Multan Street, Multan',3103.52,24,6),(12,'2025-03-21 00:00:00','Cancelled','80 Faisalabad Street, Faisalabad',1029.48,8,15),(13,'2025-03-15 00:00:00','Processing','55 Islamabad Street, Islamabad',1409.18,11,9),(14,'2025-04-06 00:00:00','Cancelled','56 Multan Street, Multan',3562.32,38,15),(15,'2025-04-02 00:00:00','Cancelled','72 Peshawar Street, Peshawar',739.96,42,15),(16,'2025-07-16 00:00:00','Cancelled','33 Peshawar Street, Peshawar',4573.39,22,8),(17,'2025-06-10 00:00:00','Cancelled','37 Karachi Street, Karachi',1866.55,5,13),(18,'2025-06-17 00:00:00','Delivered','46 Peshawar Street, Peshawar',862.40,37,18),(19,'2025-02-26 00:00:00','Delivered','46 Peshawar Street, Peshawar',2544.09,29,8),(20,'2025-02-22 00:00:00','Processing','25 Faisalabad Street, Faisalabad',4989.74,36,16),(21,'2025-04-01 00:00:00','Processing','52 Peshawar Street, Peshawar',4541.25,35,9),(22,'2025-07-15 00:00:00','Cancelled','95 Quetta Street, Quetta',2491.95,12,10),(23,'2025-10-22 00:00:00','Pending','39 Karachi Street, Karachi',3374.64,37,14),(24,'2025-07-11 00:00:00','Processing','10 Faisalabad Street, Faisalabad',4507.50,33,18),(25,'2025-10-28 00:00:00','Processing','30 Quetta Street, Quetta',2236.98,50,17),(26,'2025-01-19 00:00:00','Processing','56 Islamabad Street, Islamabad',2263.95,29,8),(27,'2025-03-23 00:00:00','Shipped','77 Faisalabad Street, Faisalabad',2947.79,3,7),(28,'2025-03-14 00:00:00','Pending','52 Faisalabad Street, Faisalabad',3022.73,10,8),(29,'2025-06-18 00:00:00','Shipped','92 Quetta Street, Quetta',4207.36,37,12),(30,'2025-05-14 00:00:00','Processing','25 Islamabad Street, Islamabad',3517.96,10,6),(31,'2025-02-12 00:00:00','Delivered','98 Karachi Street, Karachi',1232.93,5,7),(32,'2025-07-20 00:00:00','Delivered','70 Karachi Street, Karachi',1192.39,11,3),(33,'2025-06-14 00:00:00','Delivered','69 Karachi Street, Karachi',2718.98,5,17),(34,'2025-07-31 00:00:00','Pending','17 Faisalabad Street, Faisalabad',1870.14,36,7),(35,'2025-03-21 00:00:00','Cancelled','15 Peshawar Street, Peshawar',3251.31,38,17),(36,'2025-04-07 00:00:00','Pending','49 Quetta Street, Quetta',3359.30,18,10),(37,'2025-06-13 00:00:00','Cancelled','98 Quetta Street, Quetta',4081.99,43,14),(38,'2025-10-03 00:00:00','Shipped','11 Multan Street, Multan',2175.57,42,18),(39,'2025-02-14 00:00:00','Shipped','83 Peshawar Street, Peshawar',4155.35,10,13),(40,'2025-04-23 00:00:00','Shipped','62 Peshawar Street, Peshawar',2890.52,27,8),(41,'2025-04-02 00:00:00','Processing','91 Quetta Street, Quetta',3146.70,13,6),(42,'2025-06-16 00:00:00','Pending','77 Lahore Street, Lahore',2592.80,1,12),(43,'2025-10-12 00:00:00','Shipped','85 Multan Street, Multan',4475.64,37,9),(44,'2025-05-25 00:00:00','Pending','75 Multan Street, Multan',4352.00,12,20),(45,'2025-01-06 00:00:00','Shipped','58 Faisalabad Street, Faisalabad',1892.84,34,10),(46,'2025-07-07 00:00:00','Shipped','64 Lahore Street, Lahore',924.46,9,1),(47,'2025-06-27 00:00:00','Pending','19 Faisalabad Street, Faisalabad',1784.02,11,20),(48,'2025-04-13 00:00:00','Delivered','69 Lahore Street, Lahore',4325.24,49,8),(49,'2025-02-04 00:00:00','Cancelled','54 Lahore Street, Lahore',3933.60,12,13),(50,'2025-07-09 00:00:00','Cancelled','13 Karachi Street, Karachi',4505.32,43,9),(51,'2025-08-05 00:00:00','Cancelled','67 Multan Street, Multan',2313.42,1,12),(52,'2025-05-13 00:00:00','Pending','95 Faisalabad Street, Faisalabad',1678.67,31,1),(53,'2025-03-13 00:00:00','Processing','74 Islamabad Street, Islamabad',2558.47,49,11),(54,'2025-02-03 00:00:00','Delivered','66 Multan Street, Multan',2456.88,42,10),(55,'2025-10-06 00:00:00','Shipped','86 Quetta Street, Quetta',3295.92,43,19),(56,'2025-10-18 00:00:00','Shipped','32 Faisalabad Street, Faisalabad',1229.90,34,1),(57,'2025-05-31 00:00:00','Cancelled','71 Karachi Street, Karachi',2761.32,13,18),(58,'2025-02-28 00:00:00','Cancelled','48 Multan Street, Multan',529.67,1,10),(59,'2025-02-09 00:00:00','Cancelled','68 Faisalabad Street, Faisalabad',2256.19,9,17),(60,'2025-01-30 00:00:00','Cancelled','34 Multan Street, Multan',1969.13,41,12),(61,'2025-07-30 00:00:00','Pending','30 Karachi Street, Karachi',4994.10,32,13),(62,'2025-04-25 00:00:00','Delivered','85 Islamabad Street, Islamabad',2723.86,21,3),(63,'2025-10-28 00:00:00','Processing','84 Quetta Street, Quetta',2959.89,41,20),(64,'2025-02-03 00:00:00','Processing','43 Quetta Street, Quetta',2046.22,36,12),(65,'2025-02-10 00:00:00','Processing','75 Karachi Street, Karachi',609.26,4,12),(66,'2025-10-23 00:00:00','Cancelled','74 Quetta Street, Quetta',2488.28,1,13),(67,'2025-10-17 00:00:00','Pending','65 Peshawar Street, Peshawar',1006.37,21,14),(68,'2025-04-15 00:00:00','Pending','37 Lahore Street, Lahore',3767.77,49,6),(69,'2025-08-29 00:00:00','Processing','13 Peshawar Street, Peshawar',2120.38,44,16),(70,'2025-09-16 00:00:00','Delivered','24 Quetta Street, Quetta',2485.96,16,11),(71,'2025-03-11 00:00:00','Processing','96 Quetta Street, Quetta',3023.20,49,15),(72,'2025-09-13 00:00:00','Cancelled','52 Faisalabad Street, Faisalabad',2933.28,49,15),(73,'2025-05-06 00:00:00','Cancelled','13 Lahore Street, Lahore',4151.66,20,5),(74,'2025-03-02 00:00:00','Processing','82 Multan Street, Multan',3607.01,34,11),(75,'2025-10-12 00:00:00','Delivered','24 Lahore Street, Lahore',4459.63,8,9),(76,'2025-10-24 00:00:00','Delivered','23 Lahore Street, Lahore',2748.60,30,7),(77,'2025-07-24 00:00:00','Cancelled','14 Multan Street, Multan',577.95,24,1),(78,'2025-10-06 00:00:00','Cancelled','53 Peshawar Street, Peshawar',1745.24,33,2),(79,'2025-04-30 00:00:00','Processing','59 Karachi Street, Karachi',2742.83,36,10),(80,'2025-08-02 00:00:00','Delivered','84 Peshawar Street, Peshawar',3624.24,16,4);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-19 12:16:22
