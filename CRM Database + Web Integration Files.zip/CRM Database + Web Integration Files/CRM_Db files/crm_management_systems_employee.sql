-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: crm_management_systems
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `EmployeeID` int NOT NULL AUTO_INCREMENT,
  `Firstname` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Lastname` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `PhoneNumber` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `Department` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Position` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `AdminID` int DEFAULT NULL,
  PRIMARY KEY (`EmployeeID`),
  UNIQUE KEY `Email` (`Email`),
  UNIQUE KEY `PhoneNumber` (`PhoneNumber`),
  KEY `AdminID` (`AdminID`),
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`AdminID`) REFERENCES `admin` (`AdminID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Ahsan','Iqbal','ahsan.iqbal@hotmail.com','+923473044263','IT','Representative',NULL),(2,'Hira','Ali','hira.ali@crm.com','+923917771691','IT','Representative',NULL),(3,'Ali','Iqbal','ali.iqbal@yahoo.com','+923759397752','Support','Officer',NULL),(4,'Hamza','Khan','hamza.khan@yahoo.com','+923910813667','Marketing','Representative',NULL),(5,'Amna','Nadeem','amna.nadeem@yahoo.com','+923898332029','Finance','Executive',NULL),(6,'Bilal','Iqbal','bilal.iqbal@hotmail.com','+923999725311','Marketing','Manager',NULL),(7,'Zain','Rauf','zain.rauf@hotmail.com','+923893442316','Support','Executive',NULL),(8,'Ahsan','Mirza','ahsan.mirza@yahoo.com','+923332295774','Sales','Manager',NULL),(9,'Ahsan','Shah','ahsan.shah@crm.com','+923472762565','Finance','Manager',NULL),(10,'Sana','Qureshi','sana.qureshi@crm.com','+923218774625','Marketing','Representative',NULL),(11,'Sara','Khan','sara.khan@crm.com','+923727504861','Sales','Manager',NULL),(12,'Amna','Mirza','amna.mirza@yahoo.com','+923671064314','IT','Representative',NULL),(13,'Fahad','Malik','fahad.malik@yahoo.com','+923565048349','Finance','Assistant',NULL),(14,'Usman','Shah','usman.shah@gmail.com','+923176346961','Sales','Officer',NULL),(15,'Amna','Mirza','amna.mirza@gmail.com','+923934972272','IT','Executive',NULL),(16,'Amna','Qureshi','amna.qureshi@yahoo.com','+923844806255','Marketing','Representative',NULL),(17,'Bilal','Ali','bilal.ali@hotmail.com','+923268616249','Finance','Officer',NULL),(18,'Shahid','Malik','shahid.malik@hotmail.com','+923425081050','Support','Executive',NULL),(19,'Shahid','Khan','shahid.khan@crm.com','+923723446628','Sales','Manager',NULL),(20,'Laiba','Shah','laiba.shah@yahoo.com','+923232305164','IT','Executive',NULL);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-19 12:16:21
